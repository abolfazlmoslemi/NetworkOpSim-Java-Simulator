// FILE: P1/src/main/java/module-info.java

module networkoperatorsimulator.appmodule {


    requires java.desktop;
    exports com.networkopsim.game;
}